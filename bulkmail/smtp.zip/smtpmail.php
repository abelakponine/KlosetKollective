<?php
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	
	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';

	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->CharSet = 'UTF-8';
	$mail->Host       = "smtp.gmail.com"; // SMTP server example Gmail is (smtp.gmail.com)
	$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
	$mail->SMTPAuth   = true;                  // enable SMTP authentication
	$mail->Port       = 465; //25;                    // set the SMTP port for the GMAIL server (port: 465)
	$mail->Username   = "exploxi";//@gmail.com"; // SMTP account username example
	$mail->Password   = "Exploxi2#";        // SMTP account password example
	$mail->Subject 	  = "Hello smtp!";
	$mail->From 	  = "exploxi@gmail.com";
	$mail->Body       = "This is a test";
	$mail->addAddress("abelakponine@tanta.com.ng");
	if ($mail->Send()){
		echo 'message sent!';
	}
	else {
		echo var_dump(error_get_last());
	}
?>

